package com.impetus.kundera.client.crud.mappedsuperclass;

public enum Status
{

    APPROVED,PENDING
}
